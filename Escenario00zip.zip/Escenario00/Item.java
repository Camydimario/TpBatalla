import greenfoot.*;

/**
 * Define un Item en la Batalla Espacial
 */
public abstract class Item extends ActorBase {

    private double ESCALA_X = 0.7;
    private double ESCALA_Y = 0.7;

    /**
     * Establece la imagen con la escala definida
     */
    @Override
    protected void actualizarImagen() {
        int tamCelda = getWorld().getCellSize();
        GreenfootImage image = getImage();
        image.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
        setImage(image);
    }

    public abstract int serRecogido();
}
